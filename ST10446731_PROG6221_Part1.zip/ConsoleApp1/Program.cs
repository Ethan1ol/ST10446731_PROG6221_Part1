﻿using System;
using System.Media;

class Program
{
    static void Main()
    {
     
        string botlogo = @"
         __
 _(\    |@@|
(__/\__ \--/ __
   \___|----|  |   __
       \ }{ /\ )_ / _\
       /\__/\ \__O (__
      (--/\--)    \__/
      _)(  )(_
     `---''---`                 
        ";

        
        Console.WriteLine(botlogo);
        Console.WriteLine("\n Welcome to Your Cybersecurity Awareness Bot!\n");
        Console.WriteLine("Concouring the world...\n");

        Thread.Sleep(3000); 

        Console.Clear();
       

        {
            Console.WriteLine(botlogo);
            Console.WriteLine("Hi Im Blitz, your CyberSecurity Safety assistance, here to inform you about the dangers of the Cyber world");
            string filePath = @"E:\Projects\ConsoleApp1\BlitzAudio.wav";

            try
            {
                using (SoundPlayer player = new SoundPlayer(filePath))
                {
                    player.PlaySync();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing sound: " + ex.Message);
            }
           
            Console.WriteLine(botlogo);
            
            Console.Write("\nWhat's your name? ");
            string userName = Console.ReadLine();

            Console.Write("Its nice to meet you " + userName + "Ready to learn about CyberSecurity safety? because I know i am");

            Console.Write("Blitz: ");
            switch (input)
            {
                case "how are you?":
                    Console.WriteLine("IM DOING GREAT!!! Thanks for asking :)");
                    break;
                case "what’s your purpose?":
                    Console.WriteLine("I was created to assist and inform you about your CyberSecurity Safety);
                    break;
                case "what can i ask you about?":
                    Console.WriteLine("You can ask me about password safety, phishing, and safe browsing.");
                    break;
                case "password safety":
                    Console.WriteLine("Create strong passwords by using atleast 12 characters, including letters, capital letters, numbers, and symbols.");
                    break;
                case "phishing":
                    Console.WriteLine("Stay away from unknown emails or messages asking for personal information!!!. Always verify links before clicking.");
                    break;
                case "safe browsing":
                    Console.WriteLine("Use HTTPS websites, avoid downloading unknown files, and keep your browser updated.");
                    break;
                default:
                    Console.WriteLine("I'm not sure how to answer that. Try asking about password safety, phishing, and safe browsing!");
                    break;



            }
    }

}
 