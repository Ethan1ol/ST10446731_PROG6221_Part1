﻿using System;
using System.Media;
using System.IO;
using System.Threading;
using System.Collections.Generic;

class Chatbot
{
    public string Name { get; set; }

    private string userName;
    private string concernedTopic;

    public Chatbot(string name)
    {
        Name = name;
    }

    private string DetectSentiment(string input)
    {
        string[] positiveWords = {"awesome","thanks","good","great","helpful","love","amazing","great" };// the different positive words for blitzbot to pickup
        string[] negativeWords = { "concerned","dumbass","annoying","bad", "hating","hate", "angry","useless" };// the different negative words for blitzbot to pickup

        input = input.ToLower();

        foreach (string word in positiveWords)
        {
            if (input.Contains(word))
            {
                return "positive";
            }
        }

        foreach (string word in negativeWords)
        {
            if (input.Contains(word))
            {
                return "negative";
            }
        }

        return "neutral";
    }


    public void PlayVoiceGreeting()
    {
        try
        {
            SoundPlayer player = new SoundPlayer("BlitzAudio.wav"); // The Welcome audio WAV file
            player.Play();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Error playing voice greeting: " + ex.Message);
            Console.ResetColor();
        }
    }

    public void Blitz()
    {
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        PlayVoiceGreeting();

        string botLogo = @"
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
      BLITZ
         __
 _(\    |@@|
(__/\__ \--/ __
   \___|----|  |   __
       \ }{ /\ )_ / _\
       /\__/\ \__O (__)
      (--/\--)    \__/
      _)(  )(_)
     `---''---`    
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        ";

        Console.WriteLine(botLogo);
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("\n Welcome to Your Cybersecurity Awareness Bot!\n");
        Console.WriteLine("Conquering the world...\n");
        Console.ResetColor();
    }

    public void GreetUser()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("\nHi! I'm Blitz, your CyberSecurity Safety Assistant, here to inform you about the dangers of the Cyber world.\n");
        Console.ResetColor();

        
        Console.Write("\nWhat's your name?\n");
        Console.ForegroundColor = ConsoleColor.Magenta;
        userName = Console.ReadLine();
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("\nIt's nice to meet you " + userName + ". Ready to learn about CyberSecurity safety? Because I know I am!\n");
        Console.ResetColor();

        Console.Write("\nWhat topic are you most concerned about: ( phishing, passwords, privacy, scams)?\n");
        Console.ForegroundColor = ConsoleColor.Magenta;
        concernedTopic = Console.ReadLine().ToLower(); // Stores the concerned topic
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n Awesome, {userName}! I'll remember that you are concerned about {concernedTopic}.\n");// letting the user know that blitzbot will remember that.
        Console.ResetColor();

        BlitzOptions();
        BlitzAnswers();
    }

    public void BlitzOptions()
    {
        Console.ForegroundColor = ConsoleColor.DarkCyan;
        Console.WriteLine("\nYou can ask anything about cybersecurity. Some examples are:Password Safety, Phishing,scam and privacy\n");
 
    }

    public void BlitzAnswers()
    {
        Console.ForegroundColor = ConsoleColor.DarkCyan;
        Console.WriteLine($"\Hey {userName}, feel free to ask more about the topic that is concerning you: {concernedTopic}!");
        Console.ResetColor();

        // Create a Random object to select responses randomly
        Random random = new Random();

        string lastTopic = null;

        // Dictionary for keyword-based responses (using List<string> for multiple answers)
        Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>()
    {
        { "password", new List<string>()
            {
                "Combine uppercase, lowercase, numbers, and symbols. Avoid personal info.",
                "Each account should have a unique password to prevent credential stuffing.",
                "Tools like Bitwarden or LastPass help you manage complex passwords securely."
            }
        },
        { "phishing", new List<string>()
            {
                "Hover over links to preview the URL. Phishing emails often hide dangerous links.",
                "Double-check the sender’s email address and look for inconsistencies.",
                "Don’t open unexpected files, especially from unknown or untrusted sources."
            }
        },
        { "scam", new List<string>()
            {
                "Scammers often try to create panic (\"Act now or lose access!\")",
                "Offers of free money, prizes, or miracle cures are usually scams.",
                "If you're unsure, contact the company directly using official channels—not the info in the message."
            }
        },
        { "privacy", new List<string>()
            {
                "Don’t overshare personal details like your birthday, location, or school.",
                "Regularly check which apps have access to your location, camera, and microphone.",
                "On social media, customize who can see your posts and personal information."
            }
        }
    };

        string userInput;
        do
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.Write("\nAsk me anything about cybersecurity (or type 'quit' to exit): \n");
            Console.ForegroundColor = ConsoleColor.Magenta;
            userInput = Console.ReadLine()?.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nYou didn't enter anything. Try typing a question or topic.\n");
                Console.ResetColor();
                continue;
            }

            string sentiment = DetectSentiment(userInput);

            switch (sentiment)
            {
                case "positive":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nThat’s great to hear! Let’s stay positive and keep learning!\n");
                    Console.ResetColor();
                    break;
                case "negative":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nI'm sorry you're feeling that way. Hopefully, I can help make things a little better.\n");
                    Console.ResetColor();
                    break;
                   
            }


            if (userInput == "quit" || userInput == "5")
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("\nSee you again buddy, stay safe on the web :)");
                Console.ResetColor();
            }
            else
            {
                if (userInput.Contains("that") || userInput.Contains("more"))
                {
                    if (!string.IsNullOrEmpty(lastTopic))
                    {
                        List<string> responses = keywordResponses[lastTopic];
                        string randomResponse = responses[random.Next(responses.Count)];

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\nYou're asking about {lastTopic} again? Here's more:\n{randomResponse}\n");
                        Console.ResetColor();
                        continue;
                    }
                    else if (!string.IsNullOrEmpty(concernedTopic) && keywordResponses.ContainsKey(concernedTopic))
                    {
                        // Use favorite topic if no last topic
                        List<string> responses = keywordResponses[concernedTopic];
                        string randomResponse = responses[random.Next(responses.Count)];
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\nYou're interested in {concernedTopic}, right? Here's a good tip:\n{randomResponse}\n");
                        Console.ResetColor();
                        continue;
                    }
                }
                bool found = false;
                foreach (var keyword in keywordResponses.Keys)
                {
                    if (userInput.Contains(keyword))
                    {
                        // Pick a random response from the list
                        List<string> responses = keywordResponses[keyword];
                        string randomResponse = responses[random.Next(responses.Count)];

                        // Friendly intro and follow-up suggestions
                        List<string> intros = new List<string>
                            {
                            "No problem, here's some insight:",
                            "Let me break it down for you:",
                            "Here’s a quick tip that might help:",
                            "This one’s important — here’s why::"
                            };

                        List<string> followUps = new List<string>
                        {
                            "Interested in boosting your password game next?",
                            "Would you like to explore ways to avoid online scams?",
                            "Need more tips on keeping your data private?",
                            "Want to learn how to spot phishing attempts better?"
                            };


                        string randomIntro = intros[random.Next(intros.Count)];
                        string randomFollowUp = followUps[random.Next(followUps.Count)];

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\n{randomIntro}\n{randomResponse}\n");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine(randomFollowUp + "\n");
                        Console.ResetColor();
                        lastTopic = keyword; // Remember the last topic
                        found = true;

                    }
                }

                if (!found)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nI'm not sure about that topic. Try asking about password safety, phishing, scams, or privacy.\n");
                    Console.ResetColor();
                }
            }

        } while (userInput != "quit" && userInput != "5");
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Title = "Blitz - CyberSecurity Bot";
            Console.Clear();

            Chatbot bot = new Chatbot("Blitz");
            bot.Blitz();
            bot.GreetUser();

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\nPress any key to exit...");
            Console.ResetColor();
            Console.ReadKey();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nOh no😱.Something went wrong!!: " + ex.Message);
            Console.ResetColor();
        }
    }
}














