﻿using System;
using System.Collections.Generic;

namespace POEPart3
{
    public class SimpleNLPProcessor
    {
        private Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>
        {
            { "password", new List<string> { "Use strong passwords: combine letters, numbers, and symbols." } },
            { "phishing", new List<string> { "Phishing emails try to trick you—don't click suspicious links." } },
            { "scam", new List<string> { "Avoid offers that seem too good to be true online." } },
            { "privacy", new List<string> { "Be careful what personal info you share on social media." } }
        };

        public string RespondToInput(string input)
        {
            input = input.ToLower();

            foreach (var keyword in keywordResponses)
            {
                if (input.Contains(keyword.Key))
                {
                    return keyword.Value[0]; // Simple static response
                }
            }

            return null;
        }
    }
}
