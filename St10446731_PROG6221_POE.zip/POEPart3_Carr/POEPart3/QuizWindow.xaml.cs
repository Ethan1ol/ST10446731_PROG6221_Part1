﻿using System.Collections.Generic;
using System.Windows;

namespace POEPart3
{
    public partial class QuizWindow : Window
    {
        private List<QuizQuestion> questions;
        private int currentIndex = 0;
        private int score = 0;

        public QuizWindow()
        {
            InitializeComponent();
            LoadQuestions();
            ShowQuestion();
        }

        private void LoadQuestions()
        {
            questions = new List<QuizQuestion>
            {
                new QuizQuestion("What should you do if you receive a suspicious email?",
                    new List<string> { "Reply to confirm", "Click the link", "Report it as phishing", "Ignore it" }, 2),
                new QuizQuestion("True or False: '123456' is a secure password.",
                    new List<string> { "True", "False" }, 1),
                new QuizQuestion("Which is NOT a good privacy practice?",
                    new List<string> { "Sharing your address online", "Using private social media settings", "Reviewing app permissions" }, 0)
                // Add more questions here...
            };
        }

        private void ShowQuestion()
        {
            if (currentIndex < questions.Count)
            {
                var q = questions[currentIndex];
                QuestionText.Text = q.Text;
                OptionsListBox.ItemsSource = q.Options;
            }
            else
            {
                QuestionText.Text = "Quiz Completed!";
                OptionsListBox.Visibility = Visibility.Hidden;
                ScoreText.Text = $"Your Score: {score}/{questions.Count}";
            }
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentIndex < questions.Count)
            {
                var selected = OptionsListBox.SelectedIndex;
                if (selected == questions[currentIndex].CorrectIndex)
                    score++;

                currentIndex++;
                ShowQuestion();
            }
        }
    }

    public class QuizQuestion
    {
        public string Text { get; set; }
        public List<string> Options { get; set; }
        public int CorrectIndex { get; set; }

        public QuizQuestion(string text, List<string> options, int correctIndex)
        {
            Text = text;
            Options = options;
            CorrectIndex = correctIndex;
        }
    }
}
