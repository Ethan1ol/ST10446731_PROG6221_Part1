﻿
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using POEPart3;

namespace CyberSecurityChatbot
{
    public partial class MainWindow : Window
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private ActivityLog activityLogger = new ActivityLog();
        private POEPart3.SimpleNLPProcessor nlpProcessor = new POEPart3.SimpleNLPProcessor();

        private bool waitingForReminder = false;
        private string lastTaskTitle = "";

        private Quiz quiz = new Quiz();
        private QuizQuestion currentQuestion;
        private bool inQuizMode = false;
        private int correctAnswersCount = 0;

        private const string TASKS_FILE = "tasks.json";

        public MainWindow()
        {
            InitializeComponent();
            LoadTasks();

            string botLogo = @"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
      BLITZ
         __
 _(\    |@@|
(__/\__ \--/ __
   \___|----|  |   __
       \ }{ /\ )_ / _\
       /\__/\ \__O (__)
      (--/\--)    \__/
      _)(  )(_)
     `---''---`    
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";

            OutputTextBlock.Text += botLogo + "\nWelcome to Your Cybersecurity Awareness Bot!\n\n"
                + "Here's what I can help you with:\n"
                + "• Answer questions about cybersecurity (phishing, privacy, scams, passwords)\n"
                + "• Add and manage cybersecurity tasks\n"
                + "• Set reminders (e.g., \"Remind me to update my password in 3 days\")\n"
                + "• Play an interactive cybersecurity quiz\n"
                + "• Show an activity log of your recent actions\n\n"
                + "Ask me anything to get started!\n";
        }


        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string userInput = UserInputTextBox.Text.Trim();
            if (string.IsNullOrEmpty(userInput)) return;

            OutputTextBlock.Text += $"You: {userInput}\n";
            UserInputTextBox.Clear();

            if (waitingForReminder)
            {
                SetReminder(userInput);
                return;
            }

            string inputLower = userInput.ToLower();
            string sentiment = DetectSentiment(inputLower);
            switch (sentiment)
            {
                case "positive":
                    OutputTextBlock.Text += "Blitz: Great to hear! Let's keep learning!\n";
                    break;
                case "negative":
                    OutputTextBlock.Text += "Blitz: Sorry to hear that. I'm here to help.\n";
                    break;
            }

            // NLP Reminder Detection
            if (inputLower.Contains("remind") && inputLower.Contains("password") ||
                inputLower.Contains("remind") && inputLower.Contains("privacy") ||
                inputLower.Contains("remind") && inputLower.Contains("check") ||
                inputLower.StartsWith("remind me to"))
            {
                string taskTitle = Regex.Replace(userInput.Substring(userInput.ToLower().IndexOf("remind me to") + 12), "\b(in \\d+ days|tomorrow|next week)\b", "", RegexOptions.IgnoreCase).Trim();
                DateTime reminderDate = DateTime.Now;

                if (inputLower.Contains("tomorrow"))
                {
                    reminderDate = DateTime.Now.AddDays(1);
                }
                else if (inputLower.Contains("next week"))
                {
                    reminderDate = DateTime.Now.AddDays(7);
                }
                else
                {
                    Match match = Regex.Match(inputLower, @"in (\\d+) days");
                    if (match.Success && int.TryParse(match.Groups[1].Value, out int days))
                    {
                        reminderDate = DateTime.Now.AddDays(days);
                    }
                    else
                    {
                        OutputTextBlock.Text += "Blitz: I understood the reminder but couldn't detect when to remind you.\n";
                        return;
                    }
                }

                tasks.Add(new TaskItem
                {
                    Title = taskTitle,
                    Description = "Auto-created from NLP keyword detection",
                    ReminderDate = reminderDate
                });

                SaveTasks();
                activityLogger.Log($"Reminder set: '{taskTitle}' on {reminderDate:d}");
                OutputTextBlock.Text += $"Blitz: Reminder set for '{taskTitle}' on {reminderDate:d}.\n";
                return;
            }

            // Add task variations
            if (inputLower.Contains("task") && (inputLower.Contains("add") || inputLower.Contains("create")))
            {
                string title = ExtractTitle(inputLower);
                if (string.IsNullOrWhiteSpace(title)) title = "Unnamed cybersecurity task";

                tasks.Add(new TaskItem { Title = title, Description = "Cybersecurity-related task", ReminderDate = null });
                SaveTasks();
                OutputTextBlock.Text += $"Blitz: Task added: '{title}'. Would you like to set a reminder?\n";
                lastTaskTitle = title;
                waitingForReminder = true;
                activityLogger.Log($"Task added: '{title}'");
                return;
            }

            if (inputLower.Contains("quiz") || inputLower.Contains("start quiz"))
            {
                QuizWindow quizWindow = new QuizWindow();
                quizWindow.Show();
                activityLogger.Log("Quiz started");
                return;
            }

            if (inputLower.Contains("show activity") || inputLower.Contains("what have you done") || inputLower.Contains("activity log") || inputLower.Contains("log"))
            {
                var recent = activityLogger.GetRecentEntries();
                OutputTextBlock.Text += "Blitz: Here's a summary of recent actions:\n";
                foreach (string entry in recent)
                    OutputTextBlock.Text += "- " + entry + "\n";
                return;
            }

            string response = nlpProcessor.RespondToInput(inputLower);
            if (!string.IsNullOrEmpty(response))
            {
                OutputTextBlock.Text += "Blitz: " + response + "\n";
                activityLogger.Log("NLP response triggered: " + inputLower);
            }
            else
            {
                OutputTextBlock.Text += "Blitz: Sorry, I didn't understand that. Try asking about phishing, passwords, privacy, or scams.\n";
            }
        }

        private void SetReminder(string input)
        {
            DateTime reminderDate;
            if (input.Contains("day"))
            {
                string[] words = input.Split(' ');
                foreach (var word in words)
                {
                    if (int.TryParse(word, out int days))
                    {
                        reminderDate = DateTime.Now.AddDays(days);
                        TaskItem task = tasks.Find(t => t.Title == lastTaskTitle);
                        if (task != null)
                        {
                            task.ReminderDate = reminderDate;
                            SaveTasks();
                            OutputTextBlock.Text += $"Blitz: Got it! Reminder set for {reminderDate:d}.\n";
                            activityLogger.Log($"Reminder set: '{task.Title}' on {reminderDate:d}");
                        }
                        break;
                    }
                }
            }
            waitingForReminder = false;
        }

        private void SaveTasks()
        {
            string json = JsonSerializer.Serialize(tasks);
            File.WriteAllText(TASKS_FILE, json);
        }
      
        private void LoadTasks()
        {
            if (File.Exists(TASKS_FILE))
            {
                string json = File.ReadAllText(TASKS_FILE);
                tasks = JsonSerializer.Deserialize<List<TaskItem>>(json);
            }
        }

        private string DetectSentiment(string input)
        {
            string[] positiveWords = { "awesome", "thanks", "good", "great", "helpful", "love", "amazing" };
            string[] negativeWords = { "concerned", "dumbass", "annoying", "bad", "hating", "hate", "angry", "useless" };
            input = input.ToLower();
            foreach (var word in positiveWords)
                if (input.Contains(word)) return "positive";
            foreach (var word in negativeWords)
                if (input.Contains(word)) return "negative";
            return "neutral";
        }

        private string ExtractTitle(string input)
        {
            Match match = Regex.Match(input, @"(?:add|create) (?:a )?task (?:to |for )?(.*)");
            if (match.Success)
            {
                return match.Groups[1].Value.Trim();
            }
            return null;
        }
    }
}
