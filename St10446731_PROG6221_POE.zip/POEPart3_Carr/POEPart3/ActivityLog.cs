﻿

using System;
using System.Collections.Generic;
using System.Linq;

namespace POEPart3
{
    public class ActivityLog
    {
        private List<string> entries = new List<string>();

 
        public void Log(string message)  // Adds a timestamped message to the log
        {
            entries.Add($"{DateTime.Now:t} - {message}");

           
            if (entries.Count > 50)  // Keep only last 50 entries
                entries.RemoveAt(0);
        }

        public bool HasEntries()
        // Checks if log has any entries
        {
            return entries.Count > 0;
        }

        
        public List<string> GetRecentEntries(int count = 5)  // Returns the most recent 'count' entries, default 5
        {
            return entries.Skip(Math.Max(0, entries.Count - count)).ToList();
        }
    }
}


